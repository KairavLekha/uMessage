/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package callClients;

import java.io.InputStream;
import java.net.Socket;
import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.SourceDataLine;

/**
 *
 * @author Kairav
 */
public class Audio_Client {

    public static void main(String[] args) {

        try {
            // Connect to the server
            String host = "IPv4 Address";
            int port = 8000;//the port that the connection is running on. On your friends laptop you may need to change this
            Socket socket = new Socket(host, port);

            // Set up Audio_Client playback
            AudioFormat audioFormat = new AudioFormat(AudioFormat.Encoding.PCM_SIGNED,
                    44100, 16, 2, 4, 44100, false);
            SourceDataLine sourceLine = AudioSystem.getSourceDataLine(audioFormat);
            sourceLine.open(audioFormat);
            sourceLine.start();

            // Create a buffer for Audio_Client data
            byte[] buffer = new byte[1024];

            // Create an input stream to receive Audio_Client data from the server
            InputStream inputStream = socket.getInputStream();

            // Start playing Audio_Client
            int bytesRead;
            while (true) {
                bytesRead = inputStream.read(buffer, 0, buffer.length);
                sourceLine.write(buffer, 0, bytesRead);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
