/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package callServers;

import javax.sound.sampled.*;
import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;

/**
 *
 * @author Kairav
 */
public class Audio_Server {

    public static void main(String[] args) {
        try {
            // Create a ServerSocket and accept a client connection
            int port = 8099;//the port that the connection is running on. On your laptop
            ServerSocket serverSocket = new ServerSocket(port);
            System.out.println("Server is running and waiting for a client...");
            Socket clientSocket = serverSocket.accept();
            System.out.println("Client connected.");

            // Set up audio capture
            AudioFormat audioFormat = new AudioFormat(AudioFormat.Encoding.PCM_SIGNED,
                    44100, 16, 2, 4, 44100, false);
            DataLine.Info targetInfo = new DataLine.Info(TargetDataLine.class, audioFormat);
            TargetDataLine targetLine = (TargetDataLine) AudioSystem.getLine(targetInfo);
            targetLine.open(audioFormat);
            targetLine.start();

            // Set up audio playback
            AudioInputStream audioInputStream = new AudioInputStream(targetLine);
            SourceDataLine sourceLine = AudioSystem.getSourceDataLine(audioFormat);
            sourceLine.open(audioFormat);
            sourceLine.start();

            // Create a buffer for audio data
            byte[] buffer = new byte[1024];

            // Create an output stream to send audio data to the client
            OutputStream outputStream = clientSocket.getOutputStream();

            // Start streaming audio
            int bytesRead;
            while (true) {
                bytesRead = audioInputStream.read(buffer, 0, buffer.length);
                outputStream.write(buffer, 0, bytesRead);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
