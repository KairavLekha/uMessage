package callServers;

import java.net.ServerSocket;

import com.github.sarxos.webcam.Webcam;
import com.github.sarxos.webcam.WebcamPanel;
import com.github.sarxos.webcam.WebcamResolution;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.net.Socket;
import java.io.ObjectOutputStream;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
/**
 *
 * @author Kairav
 */
public class Image_Server {

    public static void main(String[] args) throws IOException {

        ImageIcon ic;
        BufferedImage br;
        int port = 8000;//the port that the connection is running on. On your laptop
        ServerSocket host = new ServerSocket(port);

        JOptionPane.showMessageDialog(null, "Click Ok to Start The Your Video");
        Webcam cam = Webcam.getDefault();
        cam.setViewSize(WebcamResolution.VGA.getSize());
        cam.open();
        showVideo(cam);

        JOptionPane.showMessageDialog(null, "Click Ok to Start The Call");
        
        Socket s = host.accept();
       
        ObjectOutputStream videoFeed = new ObjectOutputStream(s.getOutputStream());
        
        while (true) {


            br = cam.getImage();
            ic = new ImageIcon(br);

           
            videoFeed.writeObject(ic);
            videoFeed.flush();

        }
 
    }

    public static void showVideo(Webcam cam) {
        WebcamPanel panel = new WebcamPanel(cam);
        panel.setFPSDisplayed(true);
        panel.setDisplayDebugInfo(false);
        panel.setImageSizeDisplayed(true);
        panel.setMirrored(true);

        JFrame window = new JFrame("Video Feed");
        window.add(panel);
        window.setResizable(true);
        window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        window.pack();
        window.setLocationRelativeTo(null);
        window.setSize(680, 520);

        window.setVisible(true);
//
    }

}
