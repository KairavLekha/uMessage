/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package messageClient;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.util.Scanner;

/**
 *
 * @author Kairav
 */
public class Message_Client {

    private Socket socket;
    private BufferedReader br;
    private BufferedWriter bw;
    private String username;

    public Message_Client(Socket socket, String username) {
        try {
            this.socket = socket;
            this.bw = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
            this.br = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            this.username = username;
        } catch (IOException e) {
            closeEverything(socket, br, bw);
        }
    }

    public void sendMessage() {
        try {
            bw.write(username);
            bw.newLine();
            bw.flush();
            Scanner sc = new Scanner(System.in);

            while (socket.isConnected()) {
                String message = (username + ": " + sc.nextLine());
                bw.write(message);
                bw.newLine();
                bw.flush();

            }
        } catch (IOException e) {
            closeEverything(socket, br, bw);
        }
    }

    public void recieveMessage() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                String messageFromChat;
                while (socket.isConnected()) {
                    try {
                        messageFromChat = br.readLine();
                        System.out.println(messageFromChat);

                    } catch (IOException e) {
                        closeEverything(socket, br, bw);
                    }
                }
            }
        }).start();
    }

    public void closeEverything(Socket socket, BufferedReader br, BufferedWriter bw) {

        try {
            if (bw != null) {
                bw.close();
            }
            if (br != null) {
                br.close();
            }
            if (socket != null) {
                socket.close();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) throws IOException {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter your username:");
        String username = sc.nextLine();
        String host = "IPv4 Address";
        Socket socket = new Socket(host, 8020);
        Message_Client client = new Message_Client(socket, username);
        client.recieveMessage();
        client.sendMessage();
    }
}
