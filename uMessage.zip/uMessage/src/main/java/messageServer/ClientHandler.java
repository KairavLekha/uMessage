/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package messageServer;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Iterator;

/**
 *
 * @author Kairav
 */
public class ClientHandler implements Runnable {

    public static ArrayList<ClientHandler> clientHandlers = new ArrayList<>();
    private Socket socket;
    private BufferedReader br;
    private BufferedWriter bw;
    private String clientName;

    public ClientHandler(Socket socket) {
        try {
            this.socket = socket;
            this.bw = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
            this.br = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            this.clientName=br.readLine();
            clientHandlers.add(this);
            broadcast("Server: "+clientName+" has entered the chat.");
        } catch (IOException e) {
            closeEverything(socket, br, bw);
        }
    }

    @Override
    public void run() {
        String message;

        while (socket.isConnected()) {
            try {
                message = br.readLine();
                broadcast(message);
            } catch (IOException e) {
                closeEverything(socket, br, bw);
                break;
            }
        }

    }

public void broadcast(String messageSending) {
    Iterator<ClientHandler> iterator = clientHandlers.iterator();
    while (iterator.hasNext()) {
        ClientHandler clientHandler = iterator.next();
        try {
            if (!clientHandler.clientName.equals(clientName)) {
                clientHandler.bw.write(messageSending);
                clientHandler.bw.newLine();
                clientHandler.bw.flush();
            }
        } catch (IOException e) {
            closeEverything(clientHandler.socket, clientHandler.br, clientHandler.bw);
            iterator.remove(); // Remove the current client from the collection
        }
    }
}


    public void removeHandler() {
        clientHandlers.remove(this);
        broadcast("Server: "+clientName+" has left the chat.");
    }
    
    public void closeEverything(Socket socket,BufferedReader br,BufferedWriter bw){
        removeHandler();
        try{
            if(bw!=null){
              bw.close();
            }
            if(br!=null){
                br.close();
            }
            if(socket!=null){
                socket.close();
            }
        }catch(IOException e){
            e.printStackTrace();
        }
    }
}
