/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package messageServer;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

/**
 *
 * @author Kairav
 */
public class Message_Server {
    private ServerSocket serversocket;
    
    public Message_Server(ServerSocket socket){
        this.serversocket=socket;
    }
    public void start(){
        
        try{
            while (!serversocket.isClosed()) {                
                Socket socket=serversocket.accept();
                System.out.println("A new client has connected");
                ClientHandler clienthandler = new ClientHandler(socket);
                
                Thread thread = new Thread(clienthandler);
                thread.start();
            }
  
        }catch(IOException e){
            
        }
        
    }

  public void closeServerSoccket (){
      try{
          if(serversocket !=null){
              serversocket.close();
          }
      }catch(IOException e){
          e.printStackTrace();
      }
  } 
  
  
  
    public static void main(String[] args) throws IOException {
       ServerSocket serverSocket=new ServerSocket(8020);
       Message_Server server=new Message_Server(serverSocket);
       server.start();
    }
}
